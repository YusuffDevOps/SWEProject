# File Structure
## client
This folder contains all the files related to the front-end.

## server
This folder contains all the files related to the back-end.

## admin
This folder contains all the files related to the the admin page. (use to upload contain to the server)
